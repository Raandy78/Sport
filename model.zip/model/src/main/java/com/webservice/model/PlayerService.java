package com.webservice.model;

import java.util.*;

public class PlayerService {
	
	private static Map<Integer,Player> PLAYER_DATA = new HashMap<Integer,Player>();
	
	public Player addPlayer(Player s) {
		return s;
		
	}
	public Player getPlayer(int id) {
		return PLAYER_DATA.get(id);
	}
	
	public boolean delete(int id) {
		if(PLAYER_DATA.get(id) == null) {
		      return false;
		    }
		PLAYER_DATA.remove(id);
		    return true;
	}
	
	public Player[] getAllPlayers() {
	    Set<Integer> ids = PLAYER_DATA.keySet();
	    Player[] s = new Player[ids.size()];
	    int i = 0;
	    for(Integer id : ids) {
	      s[i] = PLAYER_DATA.get(id);
	      i++;
	    }
	    return s;
	  }

}
