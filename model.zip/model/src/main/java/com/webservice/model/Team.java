package com.webservice.model;

import java.net.URI;

import javax.ws.rs.*;
import javax.ws.rs.core.*;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.UriInfo;



@Path("/team")
public class Team {
	PlayerService service = new PlayerService();
	
	@Context 
	UriInfo uriInfo;
	
	public Response addPlayer(Player p) {
		Player player = service.addPlayer(p);
		if(player == null) {
			return Response.status(Response.Status.BAD_REQUEST).build();
		}
		URI uri = uriInfo.getRequestUri();
		String newUri = uri.getPath() + "/" + player.getId();
		return Response.status(Response.Status.CREATED)
					   .contentLocation(uri.resolve(newUri))
					   .build();
		
	}
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public Player getPlayer()
	{
		System.out.println("GetPlayer called");
		Player p1 = new Player(null, null,null);
		p1.setPrenom("Paul");
		p1.setNom("Pogba");
	
	return p1;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public Response getAllPlayers() {
		return Response.status(Response.Status.OK)
					   .entity(service.getAllPlayers())
				       .build();
	}
}

